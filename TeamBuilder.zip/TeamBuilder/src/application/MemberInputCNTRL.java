package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class MemberInputCNTRL {
	
	@FXML
	private AnchorPane PANE_MI;
	
	@FXML
	private Pane BACKGROUND;
	
	@FXML
	private TextField INPUT_NAME;
	
	@FXML
	private RadioButton EXP_HIGH;
	
	@FXML
	private RadioButton EXP_MODERATE;
	
	@FXML
	private RadioButton EXP_NONE;
	
	@FXML
	private TextField INPUT_ID;
	
	@FXML
	private Button ADD_MEMBER;
	
	/**
	 * Collects information from input fields in UI and validates input.
	 * 
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void AddMember(ActionEvent event) throws IOException {
		
		// - - Initial Variables
		
		String sName = "";
		String sID = "";
		String sExperience = "";
		int bError = 0;
			
		if (TB_ModelClass.iMemberCnt < TB_ModelClass.iNumMembers) {
		
			// - - Determine Experience
		
			if (EXP_HIGH.isSelected()) {
				sExperience = "High";
				bError++;
			}
			if (EXP_MODERATE.isSelected()) {
				sExperience = "Moderate";
				bError++;
			}
			if (EXP_NONE.isSelected()) {
				sExperience = "None";
				bError++;
			}
			if (bError != 1) {
				System.out.println("Invalid Selection");
				return;
			}
			
			if (!INPUT_NAME.getText().isEmpty() && !INPUT_ID.getText().isEmpty()) {
			
				sName = INPUT_NAME.getText();
				sID = INPUT_ID.getText();
			
				// - - - Add Member
			
				TB_ModelClass.AddMember(sName, sID, sExperience);
				TB_ModelClass.iMemberCnt++;
			}
			else {
				if (INPUT_NAME.getText().isEmpty())
					INPUT_NAME.setText("Invalid Name");
				if (INPUT_ID.getText().isEmpty())
					INPUT_ID.setText("Invalid ID");
				return;
			}
		}
		
		// - - Create next member or assign groups
		
		if (TB_ModelClass.iMemberCnt < TB_ModelClass.iNumMembers)
			ToMemberInput(event);
		if (TB_ModelClass.iMemberCnt == TB_ModelClass.iNumMembers)
			ToAssignGroups(event);
	}
	
	/**
	 * Changes view to show MemberInput.
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void ToMemberInput(ActionEvent event) throws IOException {
		
		PANE_MI = FXMLLoader.load(getClass().getResource("MemberInput.fxml"));
		Scene scene = new Scene(PANE_MI);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
	
	/**
	 * Changes view to show AssignGroups.
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void ToAssignGroups(ActionEvent event) throws IOException {
		
		PANE_MI = FXMLLoader.load(getClass().getResource("AssignGroups.fxml"));
		Scene scene = new Scene(PANE_MI);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
}