package application;

import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

public class AssignGroupsCNTRL {

	@FXML
	private AnchorPane PANE_AG;
	
	@FXML
	private Pane BACKGROUND;
	
	@FXML
	private ListView<String> OUTPUT_GROUPS;
	
	@FXML
	private Button SHOW_LIST;
	
	/**
	 * Fills the ListView<String> with the sorted groups.
	 */
	public void FillList() {
		
		// - - Initial Variables
		
		ArrayList<String> alList = new ArrayList<String>();
		int j = 1;
		
		// - - Clear ListView<>
		
		OUTPUT_GROUPS.getItems().clear();
		
		// - - Retrieve member information
		
		alList = TB_ModelClass.TeamSort();
		
		for (int i=0; i<alList.size(); i++) {
			
			// - - - Print group number
			
			if (i%TB_ModelClass.iGroupSize == 0) {
				OUTPUT_GROUPS.getItems().add("Group " + j);
				j++;
			}
		
			// - - - Print member information
			
			OUTPUT_GROUPS.getItems().add("\t" + alList.get(i));
		}
	}
}