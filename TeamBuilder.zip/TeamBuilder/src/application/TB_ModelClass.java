package application;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class TB_ModelClass {
	
	public static int iMemberCnt = 0;
	public static int iNumMembers;
	public static int iGroupSize;
	public static String sGroupSort;
	
	public static ArrayList<String> alList = new ArrayList<String>();
	
	/**
	 * Adds members to an ArrayList in an order based on the sort type.
	 * 
	 * @param sName
	 * 		The name of the member.
	 * @param sID
	 * 		The ID of the member.
	 * @param sExperience
	 * 		The experience of the member.
	 */
	public static void AddMember(String sName, String sID, String sExperience) {
		
		// - - Sort information by name first
		
		if (sGroupSort.equals("Alphabetical") || sGroupSort.equals("Random")) {

			alList.add(sName + "\t\t\t" + sID + "\t\t\t" + sExperience);
		}
		
		// - - Sort information by experience first
		
		if (sGroupSort.equals("Experience")) {

			alList.add(sExperience + "\t\t\t" + sName + "\t\t\t" + sID);
		}
	}
	
	/**
	 * Sorts members in ArrayList based on Alphabetical order, Experience, or Randomized.
	 * 
	 * @return
	 * 		Returns ArrayList<String> alList.
	 */
	public static ArrayList<String> TeamSort() {

		// - - Sort List
		
		if (sGroupSort == "Alphabetical" || sGroupSort == "Experience") {
			alList.sort(Comparator.comparing(String::toString));
		}
		if (sGroupSort == "Random") {
			Collections.shuffle(alList);
		}
		
		return alList;
	}
}