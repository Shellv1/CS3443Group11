package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class TeamParametersCNTRL {
	
	@FXML
	private AnchorPane PANE_TP;
	
	@FXML
	private Pane BACKGROUND;
	
	@FXML
	private TextField INPUT_TOTALMEMBERS;
	
	@FXML
	private TextField INPUT_TEAMSIZE;
	
	@FXML
	private RadioButton SORT_ALPHABETICAL;
	
	@FXML
	private RadioButton SORT_EXPERIENCE;
	
	@FXML
	private RadioButton SORT_RANDOM;
	
	@FXML
	private Button GOTO_MI;
	
	/**
	 * Collects information from input fields in UI and validates input.
	 * If input is valid, changes view to show MemberInput.
	 * 
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void ToMemberInput(ActionEvent event) throws IOException {
		
		// - - Initial Variables

		int bError = 0;
		
		// - - Determine sort type
		
		if (SORT_ALPHABETICAL.isSelected()) {
			TB_ModelClass.sGroupSort = "Alphabetical";
			bError++;
		}
		if (SORT_EXPERIENCE.isSelected()) {
			TB_ModelClass.sGroupSort = "Experience";
			bError++;
		}
		if (SORT_RANDOM.isSelected()) {
			TB_ModelClass.sGroupSort = "Random";
			bError++;
		}
		
		if (bError != 1) {
			System.out.println("Invalid Selection");
			TB_ModelClass.sGroupSort = "";
			return;
		}
		
		// - - Determine total members and max size of groups
		
		if (!INPUT_TOTALMEMBERS.getText().isEmpty() && !INPUT_TEAMSIZE.getText().isEmpty()) {
			
			TB_ModelClass.iNumMembers = Integer.parseInt(INPUT_TOTALMEMBERS.getText());
			TB_ModelClass.iGroupSize = Integer.parseInt(INPUT_TEAMSIZE.getText());
		}
		else {
			if (INPUT_TOTALMEMBERS.getText().isEmpty())
				INPUT_TOTALMEMBERS.setText("Invalid Size");
			if (INPUT_TEAMSIZE.getText().isEmpty())
				INPUT_TEAMSIZE.setText("Invalid Size");
			return;
		}
				
		// - - Create window if no errors
				
		PANE_TP = FXMLLoader.load(getClass().getResource("MemberInput.fxml"));
		Scene scene = new Scene(PANE_TP);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
}