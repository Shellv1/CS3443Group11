package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class TitleCNTRL {

	@FXML
	private AnchorPane Title_Pane;
	
	@FXML
	private Pane BCKGRND;
	
	@FXML
	private Button TO_TP;
	
	@FXML
	public void ToTeamParameters(ActionEvent event) throws IOException {
		
		Title_Pane = FXMLLoader.load(getClass().getResource("TeamParameters.fxml"));
		Scene scene = new Scene(Title_Pane);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
}
